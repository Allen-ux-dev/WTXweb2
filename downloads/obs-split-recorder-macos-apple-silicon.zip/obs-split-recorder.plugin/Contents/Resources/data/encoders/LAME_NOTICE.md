# Bundled LAME encoder notice

OBS Split Recorder may bundle the LAME MP3 encoder executable and its shared
library in release artifacts so MP3 export does not depend on Homebrew or a
separate FFmpeg installation.

LAME is a high-quality MPEG Audio Layer III encoder distributed under the
GNU Lesser General Public License. The official project is maintained at:

https://lame.sourceforge.io/

The bundled binary is kept as a separate executable/library and is invoked
only for WAV-to-MP3 conversion. No warranty is provided. Release publishers
should retain this notice and the applicable LAME license materials.
