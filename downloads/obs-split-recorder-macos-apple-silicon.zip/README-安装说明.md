# macOS 安装

1. 完全退出 OBS Studio。
2. 双击 `Install Split Recorder.command`。
3. 第一次若 macOS 阻止打开：右键该文件 → 打开 → 再选择“打开”。
4. 重新打开 OBS，进入 **停靠窗口 → 分离录制**。

安装器只会把插件复制到：

`~/Library/Application Support/obs-studio/plugins/obs-split-recorder.plugin`

它使用本机免费的临时签名，不需要 Apple Developer 付费证书。
