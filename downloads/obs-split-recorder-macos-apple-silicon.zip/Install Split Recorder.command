#!/bin/zsh
set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PLUGIN="$SCRIPT_DIR/obs-split-recorder.plugin"
DEST="$HOME/Library/Application Support/obs-studio/plugins"
if [[ ! -d "$PLUGIN" ]]; then echo "找不到 obs-split-recorder.plugin"; read -k 1; exit 1; fi
if pgrep -x "OBS" >/dev/null; then
  osascript -e 'display dialog "请先完全退出 OBS Studio，然后重新运行安装程序。" buttons {"好"} default button "好" with icon caution'
  exit 1
fi
mkdir -p "$DEST"
rm -rf "$DEST/obs-split-recorder.plugin"
cp -R "$PLUGIN" "$DEST/"
xattr -dr com.apple.quarantine "$DEST/obs-split-recorder.plugin" 2>/dev/null || true
codesign --force --deep --sign - "$DEST/obs-split-recorder.plugin"
osascript -e 'display notification "插件已安装。打开 OBS 后进入“停靠窗口 → 分离录制”。" with title "OBS Split Recorder"'
echo "安装完成：$DEST/obs-split-recorder.plugin"
echo "现在可以打开 OBS Studio。"
read -k 1 "?按任意键关闭…"
