#!/bin/zsh
set -e
PLUGIN="$HOME/Library/Application Support/obs-studio/plugins/obs-split-recorder.plugin"
if pgrep -x "OBS" >/dev/null; then echo "请先退出 OBS Studio。"; read -k 1; exit 1; fi
rm -rf "$PLUGIN"
echo "OBS Split Recorder 已卸载。"
read -k 1 "?按任意键关闭…"
